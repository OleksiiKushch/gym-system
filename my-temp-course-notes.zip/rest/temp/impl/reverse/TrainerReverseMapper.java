package org.example.mapper.impl.reverse;

import lombok.Getter;
import org.example.dto.TraineeDto;
import org.example.dto.TrainerDto;
import org.example.entity.Trainee;
import org.example.entity.Trainer;
import org.example.mapper.ReverseMapper;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Getter
@Component
public class TrainerReverseMapper implements ReverseMapper<Trainer, TrainerDto> {

    private final ReverseMapper<Trainee, TraineeDto> traineeReverseMapper;

    public TrainerReverseMapper(@Lazy ReverseMapper<Trainee, TraineeDto> traineeReverseMapper) {
        this.traineeReverseMapper = traineeReverseMapper;
    }

    @Override
    public TrainerDto map(Trainer source) {
        return TrainerDto.builder()
                .username(source.getUsername())
                .firstName(source.getFirstName())
                .lastName(source.getLastName())
                .specialization(source.getSpecialization().getName())
                .isActive(source.getIsActive())
                .trainees(source.getTrainees().stream()
                        .map(trainee -> getTraineeReverseMapper().lazyMap(trainee))
                        .toList())
                .build();
    }

    @Override
    public TrainerDto lazyMap(Trainer source) {
        return TrainerDto.builder()
                .username(source.getUsername())
                .firstName(source.getFirstName())
                .lastName(source.getLastName())
                .specialization(source.getSpecialization().getName())
                .build();
    }
}
