package org.example.mapper.impl.reverse;

import org.example.dto.TrainingDto;
import org.example.entity.Training;
import org.example.mapper.ReverseMapper;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class TrainingReverseMapper implements ReverseMapper<Training, TrainingDto> {

    @Override
    public TrainingDto map(Training source) {
        return Optional.ofNullable(source)
                .map(training -> TrainingDto.builder()
                        .trainingName(training.getTrainingName())
                        .trainingDate(training.getTrainingDate())
                        .trainingType(training.getTrainingType().getName())
                        .duration(training.getTrainingDuration())
                        .build())
                .orElseGet(TrainingDto::new);
    }

    @Override
    public TrainingDto lazyMap(Training source) {
        return map(source);
    }
}
