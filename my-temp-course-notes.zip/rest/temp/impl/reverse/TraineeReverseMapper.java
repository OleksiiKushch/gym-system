package org.example.mapper.impl.reverse;

import lombok.Getter;
import org.example.dto.TraineeDto;
import org.example.dto.TrainerDto;
import org.example.entity.Trainee;
import org.example.entity.Trainer;
import org.example.mapper.ReverseMapper;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Objects;

@Getter
@Component
public class TraineeReverseMapper implements ReverseMapper<Trainee, TraineeDto> {

    private final ReverseMapper<Trainer, TrainerDto> trainerReverseMapper;

    public TraineeReverseMapper(@Lazy ReverseMapper<Trainer, TrainerDto> trainerReverseMapper) {
        this.trainerReverseMapper = trainerReverseMapper;
    }

    @Override
    public TraineeDto map(Trainee source) {
        return TraineeDto.builder()
                .username(source.getUsername())
                .firstName(source.getFirstName())
                .lastName(source.getLastName())
                .dateOfBirthday(source.getDateOfBirthday())
                .address(source.getAddress())
                .isActive(source.getIsActive())
                .trainers(source.getTrainers().stream()
                        .map(trainer -> getTrainerReverseMapper().lazyMap(trainer))
                        .toList())
                .build();
    }

    @Override
    public TraineeDto lazyMap(Trainee source) {
        return TraineeDto.builder()
                .username(source.getUsername())
                .firstName(source.getFirstName())
                .lastName(source.getLastName())
                .build();
    }

    private String getStrDateOrNull(LocalDate date) {
        return Objects.isNull(date) ? null : date.toString();
    }
}
