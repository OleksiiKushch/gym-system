package org.example.mapper.impl.reverse;

import org.example.dto.TrainingTypeDto;
import org.example.entity.TrainingType;
import org.example.mapper.ReverseMapper;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class TrainingTypeReverseMapper implements ReverseMapper<TrainingType, TrainingTypeDto> {

    @Override
    public TrainingTypeDto map(TrainingType source) {
        return Optional.ofNullable(source)
                .map(trainingType -> TrainingTypeDto.builder()
                        .id(trainingType.getId())
                        .name(trainingType.getName())
                        .build())
                .orElseGet(TrainingTypeDto::new);
    }

    @Override
    public TrainingTypeDto lazyMap(TrainingType source) {
        return map(source);
    }
}
