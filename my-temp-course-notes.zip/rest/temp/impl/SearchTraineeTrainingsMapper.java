package org.example.mapper.impl;

import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.example.dto.form.search.SearchTraineeTrainingsPayload;
import org.example.entity.TrainingTypeEnum;
import org.example.entity.search.TraineeTrainingsCriteria;
import org.example.mapper.Mapper;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Optional;

@Getter
@Component
public class SearchTraineeTrainingsMapper implements Mapper<SearchTraineeTrainingsPayload, TraineeTrainingsCriteria> {

    private final Mapper<String, LocalDate> stringToLocalDateMapper;

    public SearchTraineeTrainingsMapper(Mapper<String, LocalDate> stringToLocalDateMapper) {
        this.stringToLocalDateMapper = stringToLocalDateMapper;
    }

    @Override
    public TraineeTrainingsCriteria map(SearchTraineeTrainingsPayload source) {
        return Optional.ofNullable(source)
                .map(payload -> (TraineeTrainingsCriteria) TraineeTrainingsCriteria.builder()
                        .fromDate(getStringToLocalDateMapper().map(source.getFromDate()))
                        .toDate(getStringToLocalDateMapper().map(source.getToDate()))
                        .trainerFirstName(source.getTrainerFirstName())
                        .trainingType(getTrainingTypeOrNull(source.getTrainingType()))
                        .build())
                .orElseGet(TraineeTrainingsCriteria::new);
    }

    private TrainingTypeEnum getTrainingTypeOrNull(String trainingType) {
        return StringUtils.isEmpty(trainingType) ? null : TrainingTypeEnum.valueOf(trainingType);
    }
}
