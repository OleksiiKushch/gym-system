package org.example.mapper.impl;

import lombok.Getter;
import org.example.dto.form.search.SearchTrainerTrainingsPayload;
import org.example.entity.search.TrainerTrainingsCriteria;
import org.example.mapper.Mapper;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Optional;

@Getter
@Component
public class SearchTrainerTrainingsMapper implements Mapper<SearchTrainerTrainingsPayload, TrainerTrainingsCriteria> {

    private final Mapper<String, LocalDate> stringToLocalDateMapper;

    public SearchTrainerTrainingsMapper(Mapper<String, LocalDate> stringToLocalDateMapper) {
        this.stringToLocalDateMapper = stringToLocalDateMapper;
    }

    @Override
    public TrainerTrainingsCriteria map(SearchTrainerTrainingsPayload source) {
        return Optional.ofNullable(source)
                .map(payload -> (TrainerTrainingsCriteria) TrainerTrainingsCriteria.builder()
                        .fromDate(getStringToLocalDateMapper().map(source.getFromDate()))
                        .toDate(getStringToLocalDateMapper().map(source.getToDate()))
                        .traineeFirstName(source.getTraineeFirstName())
                        .build())
                .orElseGet(TrainerTrainingsCriteria::new);
    }
}
