package org.example.mapper;

public interface ReverseMapper<S, T> extends Mapper<S, T> {

    T lazyMap(S source);
}
