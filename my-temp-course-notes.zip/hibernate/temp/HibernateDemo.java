package org.example;

import org.example.config.AppConfig;
import org.example.controller.TrainingController;
import org.example.controller.UserController;
import org.example.dao.impl.hibernate.HibernateTrainerDao;
import org.example.dao.impl.hibernate.HibernateTrainingDao;
import org.example.dto.form.ChangePasswordForm;
import org.example.dto.form.CreateTrainingForm;
import org.example.dto.form.LoginForm;
import org.example.dto.form.RegistrationTraineeForm;
import org.example.dto.form.RegistrationTrainerForm;
import org.example.dto.form.UpdateTraineeForm;
import org.example.entity.TrainingTypeEnum;
import org.example.entity.search.TraineeTrainingsCriteria;
import org.example.entity.search.TrainerTrainingsCriteria;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.time.LocalDate;

public class HibernateDemo {

    public static void main(String[] args) {
        var context = new AnnotationConfigApplicationContext(AppConfig.class);

        var userController = context.getBean(UserController.class);
        var trainingController = context.getBean(TrainingController.class);

        tryToRegisterTraineeWithInvalidData(userController);
        registerTrainee(userController);
        registerAnotherOneTrainee(userController);
        registerTrainer(userController);
        registerTrainerWithoutSpecialization(userController);

        anonymousUserTryToChagePassword(userController);

        tryToLoginWithIncorrectUsername(userController);
        tryToLoginWithIncorrectPassword(userController);
        tryToLoginWithEmptyData(userController);
        login(userController);

        tryToChagePasswordButIncorrectCurrentPassword(userController);
        changePassword(userController);

        tryToUpdateProfileWithInvalidData(userController);
        updateProfile(userController);

        tryToCreateNewTrainingButSomeFieldsIsEmpty(trainingController);
        createNewTraining(trainingController);
        createAnotherOneTraining1(trainingController);
        createAnotherOneTraining2(trainingController);

        checkCriteria(context);
        checkFindAllThatNotAssignedOnTrainee(context);

        tryToDeleteActiveUser(userController);
        userDeactivateHisAccount(userController);
        deactivatedUserTryLogin(userController);
        anonymousUserTryToDeleteTrainee(userController);
        someoneLikeManagerLogin(userController);
        deleteTrainee(userController);

    }

    private static void tryToRegisterTraineeWithInvalidData(UserController userController) {
        var registrationTraineeForm = new RegistrationTraineeForm(
                "", "", "", "", "", "");
        userController.registerTrainee(registrationTraineeForm);
    }

    private static void registerTrainee(UserController userController) {
        var registrationTraineeForm = new RegistrationTraineeForm(
                "John", "Doe", "123456", "123456", "1990-01-01", "321 Main St");
        userController.registerTrainee(registrationTraineeForm);
    }

    private static void registerAnotherOneTrainee(UserController userController) {
        var registrationTraineeForm = new RegistrationTraineeForm(
                "Jessica", "White", "123456", "123456", "1990-01-03", "123 Main St");
        userController.registerTrainee(registrationTraineeForm);
    }

    private static void registerTrainer(UserController userController) {
        var registrationTrainerForm = new RegistrationTrainerForm(
                "Jack", "Green", "123456", "123456", TrainingTypeEnum.BOXING.name());
        userController.registerTrainer(registrationTrainerForm);
    }

    private static void registerTrainerWithoutSpecialization(UserController userController) {
        var registrationTrainerForm = new RegistrationTrainerForm(
                "Jim", "Smith", "", "", "");
        userController.registerTrainer(registrationTrainerForm);
    }

    private static void anonymousUserTryToChagePassword(UserController userController) {
        var changePasswordForm = new ChangePasswordForm("123456", "654321", "654321");
        userController.changePassword(changePasswordForm);
    }

    private static void tryToLoginWithIncorrectUsername(UserController userController) {
        var loginForm = new LoginForm("John.Doe99", "123456");
        userController.loginUser(loginForm);
    }

    private static void tryToLoginWithIncorrectPassword(UserController userController) {
        var loginForm = new LoginForm("John.Doe", "123457");
        userController.loginUser(loginForm);
    }

    private static void tryToLoginWithEmptyData(UserController userController) {
        var loginForm = new LoginForm("", "");
        userController.loginUser(loginForm);
    }

    private static void login(UserController userController) {
        var loginForm = new LoginForm("John.Doe", "123456");
        userController.loginUser(loginForm);
    }

    private static void tryToChagePasswordButIncorrectCurrentPassword(UserController userController) {
        var changePasswordForm = new ChangePasswordForm("123457", "654321", "654321");
        userController.changePassword(changePasswordForm);
    }

    private static void changePassword(UserController userController) {
        var changePasswordForm = new ChangePasswordForm("123456", "654321", "654321");
        userController.changePassword(changePasswordForm);
    }

    private static void tryToUpdateProfileWithInvalidData(UserController userController) {
        var updateTraineeForm = new UpdateTraineeForm("John", "", "", "321 Main St 123");
        userController.updateTrainee(updateTraineeForm);
    }

    private static void updateProfile(UserController userController) {
        var updateTraineeForm = new UpdateTraineeForm("JohnNew", "DoeNew", "", "321 Main St 123");
        userController.updateTrainee(updateTraineeForm);
    }

    private static void tryToCreateNewTrainingButSomeFieldsIsEmpty(TrainingController trainingController) {
        var createTrainingForm = new CreateTrainingForm("John.Doe", "Jack.Green", "", TrainingTypeEnum.BOXING.name(), "", "");
        trainingController.organizeTraining(createTrainingForm);
    }

    private static void createNewTraining(TrainingController trainingController) {
        var createTrainingForm = new CreateTrainingForm("John.Doe", "Jack.Green", "New boxing training", TrainingTypeEnum.BOXING.name(), "1990-01-05", "12");
        trainingController.organizeTraining(createTrainingForm);
    }

    private static void createAnotherOneTraining1(TrainingController trainingController) {
        var createTrainingForm = new CreateTrainingForm("John.Doe", "Jack.Green", "Basic yoga training", TrainingTypeEnum.YOGA.name(), "1990-01-08", "7");
        trainingController.organizeTraining(createTrainingForm);
    }

    private static void createAnotherOneTraining2(TrainingController trainingController) {
        var createTrainingForm = new CreateTrainingForm("Jessica.White", "Jim.Smith", "Basic yoga training", TrainingTypeEnum.YOGA.name(), "1990-01-08", "7");
        trainingController.organizeTraining(createTrainingForm);
    }


    private static void tryToDeleteActiveUser(UserController userController) {
        userController.deleteTrainee("John.Doe");
    }

    private static void userDeactivateHisAccount(UserController userController) {
        userController.deactivateUser();
    }

    private static void deactivatedUserTryLogin(UserController userController) {
        var loginForm = new LoginForm("John.Doe", "654321");
        userController.loginUser(loginForm);
    }

    private static void anonymousUserTryToDeleteTrainee(UserController userController) {
        userController.deleteTrainee("John.Doe");
    }

    private static void someoneLikeManagerLogin(UserController userController) {
        var loginForm = new LoginForm("Jack.Green", "123456");
        userController.loginUser(loginForm);
    }

    private static void deleteTrainee(UserController userController) {
        userController.deleteTrainee("John.Doe");
    }


    private static void checkCriteria(ApplicationContext context) {
        var hibernateTrainingDao = context.getBean(HibernateTrainingDao.class);

        var traineeCriteria = TraineeTrainingsCriteria.builder()
                .traineeUsername("John.Doe")
                .fromDate(LocalDate.parse("1990-01-04"))
                .toDate(LocalDate.parse("1990-01-09"))
                .trainerFirstName("Jack")
                .trainingType(TrainingTypeEnum.BOXING)
                .build();
        var result1 = hibernateTrainingDao.findTraineeTrainingsByCriteria(traineeCriteria);
        System.out.println(result1);

        traineeCriteria = TraineeTrainingsCriteria.builder()
                .build();
        result1 = hibernateTrainingDao.findTraineeTrainingsByCriteria(traineeCriteria);
        System.out.println(result1);

        var trainerCriteria = TrainerTrainingsCriteria.builder()
                .trainerUsername("Jack.Green")
                .fromDate(LocalDate.parse("1990-01-04"))
                .toDate(LocalDate.parse("1990-01-09"))
                .traineeFirstName("JohnNew")
                .build();
        var result2 = hibernateTrainingDao.findTrainerTrainingsByCriteria(trainerCriteria);
        System.out.println(result2);

        trainerCriteria = TrainerTrainingsCriteria.builder()
                .trainerUsername(null)
                .fromDate(null)
                .toDate(null)
                .traineeFirstName(null)
                .build();
        result2 = hibernateTrainingDao.findTrainerTrainingsByCriteria(trainerCriteria);
        System.out.println(result2);
    }

    private static void checkFindAllThatNotAssignedOnTrainee(ApplicationContext context) {
        var trainerDao = context.getBean(HibernateTrainerDao.class);
        System.out.println(trainerDao.findAll());
        System.out.println(trainerDao.findAllThatNotAssignedOnTrainee("John.Doe"));
    }
}
