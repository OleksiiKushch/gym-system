package org.example.constants;

/**
 * Constants for validations layer (DTO field names, error messages / codes, etc.)
 */
public class ValidationConstants {

    public static final String FIRST_NAME_FIELD = "firstName";
    public static final String LAST_NAME_FIELD = "lastName";
    public static final String DATE_OF_BIRTHDAY_FIELD = "dateOfBirthday";
    public static final String SPECIALIZATION_FIELD = "specialization";
    public static final String USERNAME_FIELD = "username";
    public static final String PASSWORD_FIELD = "password";
    public static final String CURRENT_PASSWORD_FIELD = "currentPassword";
    public static final String NEW_PASSWORD_FIELD = "newPassword";
    public static final String CONFIRM_PASSWORD_FIELD = "confirmPassword";
    public static final String TRAINING_NAME_FIELD = "trainingName";
    public static final String TRAINING_TYPE_FIELD = "trainingType";
    public static final String TRAINING_DATE_FIELD = "trainingDate";
    public static final String DURATION_FIELD = "duration";

    public static final String FIRST_NAME_EMPTY_MESSAGE_CODE = "firstname.empty";
    public static final String FIRST_NAME_EMPTY_DEFAULT_MESSAGE = "First name is required";
    public static final String LAST_NAME_EMPTY_MESSAGE_CODE = "lastname.empty";
    public static final String LAST_NAME_EMPTY_DEFAULT_MESSAGE = "Last name is required";
    public static final String INVALIDE_DATE_FORMAT_MESSAGE_CODE = "dateFormat.invalid";
    public static final String INVALIDE_DATE_FORMAT_DEFAULT_MESSAGE = "This is invalid date format: %s";
    public static final String USERNAME_EMPTY_MESSAGE_CODE = "username.empty";
    public static final String USERNAME_EMPTY_DEFAULT_MESSAGE = "Username is empty";
    public static final String PASSWORD_EMPTY_MESSAGE_CODE = "password.empty";
    public static final String PASSWORD_EMPTY_DEFAULT_MESSAGE = "Password is empty";
    public static final String SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE = "specialization.doesNotExist";
    public static final String SPECIALIZATION_DOES_NOT_EXIST_DEFAULT_MESSAGE = "Specialization with name: %s does not exist";
    public static final String CURRENT_PASSWORD_EMPTY_MESSAGE_CODE = "currentPassword.empty";
    public static final String CURRENT_PASSWORD_EMPTY_DEFAULT_MESSAGE = "Current password is empty";
    public static final String NEW_PASSWORD_EMPTY_MESSAGE_CODE = "newPassword.empty";
    public static final String NEW_PASSWORD_EMPTY_DEFAULT_MESSAGE = "New password is empty";
    public static final String CONFIRM_PASSWORD_EMPTY_MESSAGE_CODE = "confirmPassword.empty";
    public static final String CONFIRM_PASSWORD_EMPTY_DEFAULT_MESSAGE = "Confirm password is empty";
    public static final String CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE = "confirmPassword.notMatch";
    public static final String CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE = "Password and confirm password do not match";
    public static final String TRAINING_NAME_EMPTY_MESSAGE_CODE = "trainingName.empty";
    public static final String TRAINING_NAME_EMPTY_DEFAULT_MESSAGE = "Training name is required";
    public static final String TRAINING_TYPE_DOES_NOT_EXIST_MESSAGE_CODE = "trainingType.doesNotExist";
    public static final String TRAINING_TYPE_DOES_NOT_EXIST_DEFAULT_MESSAGE = "Training type with name: %s does not exist";
    public static final String TRAINING_DATE_EMPTY_MESSAGE_CODE = "trainingDate.empty";
    public static final String TRAINING_DATE_EMPTY_DEFAULT_MESSAGE = "Training date is required";
    public static final String DURATION_EMPTY_MESSAGE_CODE = "duration.empty";
    public static final String DURATION_EMPTY_DEFAULT_MESSAGE = "Training duration is required";
    public static final String INVALIDE_NUMBER_FORMAT_MESSAGE_CODE = "numberFormat.invalid";
    public static final String INVALIDE_NUMBER_FORMAT_DEFAULT_MESSAGE = "This is invalid number format: %s";

}
