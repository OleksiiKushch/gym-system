package org.example.validator.training;

import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.example.dto.form.CreateTrainingForm;
import org.example.validator.DateValidation;
import org.example.validator.EmptyFieldValidation;
import org.example.validator.IntegerValidation;
import org.example.validator.TrainingTypeValidation;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.time.format.DateTimeFormatter;

import static org.example.constants.ValidationConstants.DURATION_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.DURATION_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.DURATION_FIELD;
import static org.example.constants.ValidationConstants.INVALIDE_DATE_FORMAT_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.INVALIDE_DATE_FORMAT_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.INVALIDE_NUMBER_FORMAT_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.INVALIDE_NUMBER_FORMAT_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.TRAINING_DATE_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.TRAINING_DATE_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.TRAINING_DATE_FIELD;
import static org.example.constants.ValidationConstants.TRAINING_NAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.TRAINING_NAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.TRAINING_NAME_FIELD;
import static org.example.constants.ValidationConstants.TRAINING_TYPE_DOES_NOT_EXIST_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.TRAINING_TYPE_DOES_NOT_EXIST_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.TRAINING_TYPE_FIELD;

@Getter
@Component
public class CreateTrainingFormValidator implements Validator,
        EmptyFieldValidation, DateValidation, TrainingTypeValidation, IntegerValidation {

    private final DateTimeFormatter dateTimeFormatter;

    public CreateTrainingFormValidator(DateTimeFormatter dateTimeFormatter) {
        this.dateTimeFormatter = dateTimeFormatter;
    }

    @Override
    public boolean supports(@NonNull Class<?> clazz) {
        return CreateTrainingForm.class.equals(clazz);
    }

    @Override
    public void validate(@NonNull Object target, @NonNull Errors errors) {
        CreateTrainingForm form = (CreateTrainingForm) target;

        checkEmptyField(form.getTrainingName(),
                TRAINING_NAME_FIELD, TRAINING_NAME_EMPTY_MESSAGE_CODE, TRAINING_NAME_EMPTY_DEFAULT_MESSAGE, errors);

        if (StringUtils.isNotEmpty(form.getTrainingType())) {
            validateTrainingType(form.getTrainingType(), TRAINING_TYPE_FIELD, TRAINING_TYPE_DOES_NOT_EXIST_MESSAGE_CODE,
                    TRAINING_TYPE_DOES_NOT_EXIST_DEFAULT_MESSAGE, errors);
        }

        String trainingDate = form.getTrainingDate();
        if (!checkEmptyField(trainingDate,
                TRAINING_DATE_FIELD, TRAINING_DATE_EMPTY_MESSAGE_CODE, TRAINING_DATE_EMPTY_DEFAULT_MESSAGE, errors)) {
            validateDate(trainingDate,
                    TRAINING_DATE_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, INVALIDE_DATE_FORMAT_DEFAULT_MESSAGE, errors);
        }

        String duration = form.getDuration();
        if (!checkEmptyField(duration,
                DURATION_FIELD, DURATION_EMPTY_MESSAGE_CODE, DURATION_EMPTY_DEFAULT_MESSAGE, errors)) {
            validateInteger(duration,
                    DURATION_FIELD, INVALIDE_NUMBER_FORMAT_MESSAGE_CODE, INVALIDE_NUMBER_FORMAT_DEFAULT_MESSAGE, errors);
        }
    }
}
