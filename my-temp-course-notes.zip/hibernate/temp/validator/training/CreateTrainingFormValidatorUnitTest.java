package org.example.validator.training;

import org.apache.commons.lang3.StringUtils;
import org.example.dto.form.CreateTrainingForm;
import org.example.entity.TrainingTypeEnum;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import java.time.format.DateTimeFormatter;

import static org.example.constants.ValidationConstants.DURATION_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.DURATION_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.DURATION_FIELD;
import static org.example.constants.ValidationConstants.INVALIDE_DATE_FORMAT_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.INVALIDE_NUMBER_FORMAT_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.TRAINING_DATE_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.TRAINING_DATE_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.TRAINING_DATE_FIELD;
import static org.example.constants.ValidationConstants.TRAINING_NAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.TRAINING_NAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.TRAINING_NAME_FIELD;
import static org.example.constants.ValidationConstants.TRAINING_TYPE_DOES_NOT_EXIST_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.TRAINING_TYPE_FIELD;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CreateTrainingFormValidatorUnitTest {

    private static final String TRAINING_NAME = "Test training";
    private static final String TRAINING_TYPE = TrainingTypeEnum.BOXING.name();
    private static final String INVALID_TRAINING_TYPE = "TROLLING";
    private static final String TRAINING_DATE = "1990-01-01";
    private static final String DATE_IN_INCORRECT_FORMAT = "2/23/2021";
    private static final String DURATION = "7";
    private static final String DURATION_IN_INCORECT_FORMAT = "VII";
    private static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
    private static final String EXPECTED_MESSAGE_IF_TRAINING_TYPE_WERE_INVALID = "Training type with name: BOXING does not exist";
    private static final String EXPECTED_MESSAGE_IF_TRAINING_TYPE_WERE_EMPTY = "Training type with name: does not exist";
    private static final String EXPECTED_MESSAGE_WHEN_TRAINING_TYPE_INVALID = "Training type with name: TROLLING does not exist";
    private static final String EXPECTED_MESSAGE_IF_DATE_WERE_IN_INCORRECT_FORMAT = "This is invalid date format: 1990-01-01";
    private static final String EXPECTED_MESSAGE_IF_DATE_WERE_EMPTY = "This is invalid date format: ";
    private static final String EXPECTED_MESSAGE_IF_DATE_IN_INCORRECT_FORMAT = "This is invalid date format: 2/23/2021";
    private static final String EXPECTED_MESSAGE_IF_DURATION_WERE_IN_INCORRECT_FORMAT = "This is invalid number format: 7";
    private static final String EXPECTED_MESSAGE_IF_DURATION_WERE_EMPTY = "This is invalid number format: ";
    private static final String EXPECTED_MESSAGE_IF_DURATION_IN_INCORRECT_FORMAT = "This is invalid number format: VII";

    @InjectMocks
    CreateTrainingFormValidator testInstance;

    @Spy
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DEFAULT_DATE_FORMAT);

    @Mock
    Object anyObject;
    @Spy
    CreateTrainingForm createTrainingForm = new CreateTrainingForm(TRAINING_NAME, TRAINING_TYPE, TRAINING_DATE, DURATION);
    @Spy
    Errors errors  = new BeanPropertyBindingResult(createTrainingForm, "createTrainingForm");

    @Test
    void shouldSupport() {
        var actualResult = testInstance.supports(createTrainingForm.getClass());

        assertTrue(actualResult);
    }

    @Test
    void shouldNotSupport() {
        var actualResult = testInstance.supports(anyObject.getClass());

        assertFalse(actualResult);
    }

    @Test
    void shouldNotRejectEnyField_whenEverythingIsOk() {
        testInstance.validate(createTrainingForm, errors);

        verify(errors, never()).rejectValue(TRAINING_NAME_FIELD, TRAINING_NAME_EMPTY_MESSAGE_CODE, TRAINING_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_TYPE_FIELD, TRAINING_TYPE_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_TRAINING_TYPE_WERE_INVALID);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, TRAINING_DATE_EMPTY_MESSAGE_CODE, TRAINING_DATE_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_WERE_IN_INCORRECT_FORMAT);
        verify(errors, never()).rejectValue(DURATION_FIELD, DURATION_EMPTY_MESSAGE_CODE, DURATION_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DURATION_FIELD, INVALIDE_NUMBER_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DURATION_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldNotRejectEnyField_whenOptionalFieldsAreEmpty() {
        when(createTrainingForm.getTrainingType()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(createTrainingForm, errors);

        verify(errors, never()).rejectValue(TRAINING_NAME_FIELD, TRAINING_NAME_EMPTY_MESSAGE_CODE, TRAINING_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_TYPE_FIELD, TRAINING_TYPE_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_TRAINING_TYPE_WERE_EMPTY);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, TRAINING_DATE_EMPTY_MESSAGE_CODE, TRAINING_DATE_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_WERE_IN_INCORRECT_FORMAT);
        verify(errors, never()).rejectValue(DURATION_FIELD, DURATION_EMPTY_MESSAGE_CODE, DURATION_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DURATION_FIELD, INVALIDE_NUMBER_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DURATION_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldRejectTrainingName_whenEmpty() {
        when(createTrainingForm.getTrainingName()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(createTrainingForm, errors);

        verify(errors).rejectValue(TRAINING_NAME_FIELD, TRAINING_NAME_EMPTY_MESSAGE_CODE, TRAINING_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_TYPE_FIELD, TRAINING_TYPE_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_TRAINING_TYPE_WERE_INVALID);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, TRAINING_DATE_EMPTY_MESSAGE_CODE, TRAINING_DATE_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_WERE_IN_INCORRECT_FORMAT);
        verify(errors, never()).rejectValue(DURATION_FIELD, DURATION_EMPTY_MESSAGE_CODE, DURATION_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DURATION_FIELD, INVALIDE_NUMBER_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DURATION_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldRejectTrainingType_whenDoesNotExist() {
        when(createTrainingForm.getTrainingType()).thenReturn(INVALID_TRAINING_TYPE);

        testInstance.validate(createTrainingForm, errors);

        verify(errors, never()).rejectValue(TRAINING_NAME_FIELD, TRAINING_NAME_EMPTY_MESSAGE_CODE, TRAINING_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(TRAINING_TYPE_FIELD, TRAINING_TYPE_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_WHEN_TRAINING_TYPE_INVALID);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, TRAINING_DATE_EMPTY_MESSAGE_CODE, TRAINING_DATE_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_WERE_IN_INCORRECT_FORMAT);
        verify(errors, never()).rejectValue(DURATION_FIELD, DURATION_EMPTY_MESSAGE_CODE, DURATION_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DURATION_FIELD, INVALIDE_NUMBER_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DURATION_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldRejectTrainingDate_whenEmpty() {
        when(createTrainingForm.getTrainingDate()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(createTrainingForm, errors);

        verify(errors, never()).rejectValue(TRAINING_NAME_FIELD, TRAINING_NAME_EMPTY_MESSAGE_CODE, TRAINING_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_TYPE_FIELD, TRAINING_TYPE_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_TRAINING_TYPE_WERE_INVALID);
        verify(errors).rejectValue(TRAINING_DATE_FIELD, TRAINING_DATE_EMPTY_MESSAGE_CODE, TRAINING_DATE_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_WERE_EMPTY);
        verify(errors, never()).rejectValue(DURATION_FIELD, DURATION_EMPTY_MESSAGE_CODE, DURATION_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DURATION_FIELD, INVALIDE_NUMBER_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DURATION_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldRejectTrainingDate_whenIncorrectFormat() {
        when(createTrainingForm.getTrainingDate()).thenReturn(DATE_IN_INCORRECT_FORMAT);

        testInstance.validate(createTrainingForm, errors);

        verify(errors, never()).rejectValue(TRAINING_NAME_FIELD, TRAINING_NAME_EMPTY_MESSAGE_CODE, TRAINING_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_TYPE_FIELD, TRAINING_TYPE_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_TRAINING_TYPE_WERE_INVALID);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, TRAINING_DATE_EMPTY_MESSAGE_CODE, TRAINING_DATE_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(TRAINING_DATE_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_IN_INCORRECT_FORMAT);
        verify(errors, never()).rejectValue(DURATION_FIELD, DURATION_EMPTY_MESSAGE_CODE, DURATION_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DURATION_FIELD, INVALIDE_NUMBER_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DURATION_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldRejectDuration_whenEmpty() {
        when(createTrainingForm.getDuration()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(createTrainingForm, errors);

        verify(errors, never()).rejectValue(TRAINING_NAME_FIELD, TRAINING_NAME_EMPTY_MESSAGE_CODE, TRAINING_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_TYPE_FIELD, TRAINING_TYPE_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_TRAINING_TYPE_WERE_INVALID);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, TRAINING_DATE_EMPTY_MESSAGE_CODE, TRAINING_DATE_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_WERE_IN_INCORRECT_FORMAT);
        verify(errors).rejectValue(DURATION_FIELD, DURATION_EMPTY_MESSAGE_CODE, DURATION_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DURATION_FIELD, INVALIDE_NUMBER_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DURATION_WERE_EMPTY);
    }

    @Test
    void shouldRejectDuration_whenIncorrectFormat() {
        when(createTrainingForm.getDuration()).thenReturn(DURATION_IN_INCORECT_FORMAT);

        testInstance.validate(createTrainingForm, errors);

        verify(errors, never()).rejectValue(TRAINING_NAME_FIELD, TRAINING_NAME_EMPTY_MESSAGE_CODE, TRAINING_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_TYPE_FIELD, TRAINING_TYPE_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_TRAINING_TYPE_WERE_INVALID);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, TRAINING_DATE_EMPTY_MESSAGE_CODE, TRAINING_DATE_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(TRAINING_DATE_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_WERE_IN_INCORRECT_FORMAT);
        verify(errors, never()).rejectValue(DURATION_FIELD, DURATION_EMPTY_MESSAGE_CODE, DURATION_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(DURATION_FIELD, INVALIDE_NUMBER_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DURATION_IN_INCORRECT_FORMAT);
    }
}