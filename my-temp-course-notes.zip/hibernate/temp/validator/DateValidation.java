package org.example.validator;

import org.springframework.validation.Errors;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public interface DateValidation {

    DateTimeFormatter getDateTimeFormatter();

    default void validateDate(String dateStr, String field, String messageCode, String defaultMessage, Errors errors) {
        if (!validateDate(dateStr)) {
            errors.rejectValue(field, messageCode, formMessage(defaultMessage, dateStr));
        }
    }

    private boolean validateDate(String dateStr) {
        try {
            LocalDate ignored = LocalDate.parse(dateStr, getDateTimeFormatter());
        } catch (DateTimeParseException ignored) {
            return false;
        }
        return true;
    }

    private String formMessage(String message, Object... args) {
        return String.format(message, args);
    }
}
