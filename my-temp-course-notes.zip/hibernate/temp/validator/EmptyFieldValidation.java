package org.example.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.Errors;

public interface EmptyFieldValidation {

    default boolean checkEmptyField(String value, String field, String messageCode, String defaultMessage, Errors errors) {
        if (StringUtils.isEmpty(value)) {
            errors.rejectValue(field, messageCode, defaultMessage);
            return true;
        }
        return false;
    }
}
