package org.example.validator;

import org.example.entity.TrainingTypeEnum;
import org.springframework.validation.Errors;

public interface TrainingTypeValidation {

    default void validateTrainingType(String trainingType, String fieldName, String messageCode, String defaultMessage, Errors errors) {
        try {
            TrainingTypeEnum.valueOf(trainingType);
        } catch(IllegalArgumentException exception) {
            errors.rejectValue(fieldName, messageCode, formMessage(defaultMessage, trainingType));
        }
    }

    private String formMessage(String message, Object... args) {
        return String.format(message, args);
    }
}
