package org.example.validator;

import org.springframework.validation.Errors;

public interface IntegerValidation {

    default void validateInteger(String numberStr, String field, String messageCode, String defaultMessage, Errors errors) {
        if (!validateInteger(numberStr)) {
            errors.rejectValue(field, messageCode, formMessage(defaultMessage, numberStr));
        }
    }

    private boolean validateInteger(String numberStr) {
        try {
            Integer ignored = Integer.parseInt(numberStr);
        } catch (NumberFormatException ignored) {
            return false;
        }
        return true;
    }

    private String formMessage(String message, Object... args) {
        return String.format(message, args);
    }
}
