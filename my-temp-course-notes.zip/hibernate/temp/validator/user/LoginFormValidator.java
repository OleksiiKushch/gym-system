package org.example.validator.user;

import org.example.dto.form.LoginForm;
import org.example.validator.EmptyFieldValidation;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import static org.example.constants.ValidationConstants.PASSWORD_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.PASSWORD_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.PASSWORD_FIELD;
import static org.example.constants.ValidationConstants.USERNAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.USERNAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.USERNAME_FIELD;

@Component
public class LoginFormValidator implements Validator, EmptyFieldValidation {

    @Override
    public boolean supports(@NonNull Class<?> clazz) {
        return LoginForm.class.equals(clazz);
    }

    @Override
    public void validate(@NonNull Object target, @NonNull Errors errors) {
        LoginForm form = (LoginForm) target;

        checkEmptyField(form.getUsername(), USERNAME_FIELD, USERNAME_EMPTY_MESSAGE_CODE, USERNAME_EMPTY_DEFAULT_MESSAGE, errors);
        checkEmptyField(form.getPassword(), PASSWORD_FIELD, PASSWORD_EMPTY_MESSAGE_CODE, PASSWORD_EMPTY_DEFAULT_MESSAGE, errors);
    }
}
