package org.example.validator.user.trainer;

import org.apache.commons.lang3.StringUtils;
import org.example.validator.TrainingTypeValidation;
import org.example.validator.user.AbstractUserFieldsValidator;
import org.springframework.validation.Errors;

import static org.example.constants.ValidationConstants.SPECIALIZATION_DOES_NOT_EXIST_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.SPECIALIZATION_FIELD;

public abstract class AbstractTrainerFieldsValidator extends AbstractUserFieldsValidator implements TrainingTypeValidation {

    protected void validateTrainerFields(String firstName, String lastName, String specialization, Errors errors) {

        validateUserFields(firstName, lastName, errors);

        if (StringUtils.isNotEmpty(specialization)) {
            validateTrainingType(specialization, SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE,
                    SPECIALIZATION_DOES_NOT_EXIST_DEFAULT_MESSAGE,errors);
        }
    }
}
