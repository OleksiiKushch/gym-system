package org.example.validator.user.trainer;

import org.apache.commons.lang3.StringUtils;
import org.example.dto.form.UpdateTrainerForm;
import org.example.entity.TrainingTypeEnum;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import static org.example.constants.ValidationConstants.FIRST_NAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.FIRST_NAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.FIRST_NAME_FIELD;
import static org.example.constants.ValidationConstants.LAST_NAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.LAST_NAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.LAST_NAME_FIELD;
import static org.example.constants.ValidationConstants.SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.SPECIALIZATION_FIELD;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UpdateTrainerFormValidatorUnitTest {

    private static final String FIRST_NAME = "John";
    private static final String LAST_NAME = "Doe";
    private static final String SPECIALIZATION = TrainingTypeEnum.YOGA.name();
    private static final String INVALID_SPECIALIZATION = "TROLLING";

    private static final String EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_INVALID = "Specialization with name: YOGA does not exist";
    private static final String EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_EMPTY = "Specialization with name: does not exist";
    private static final String EXPECTED_MESSAGE_WHEN_SPECIALIZATION_INVALID = "Specialization with name: TROLLING does not exist";

    @Spy
    UpdateTrainerFormValidator testInstance;

    @Mock
    Object anyObject;
    @Spy
    UpdateTrainerForm updateTrainerForm = new UpdateTrainerForm(
            FIRST_NAME, LAST_NAME, SPECIALIZATION);
    @Spy
    Errors errors  = new BeanPropertyBindingResult(updateTrainerForm, "updateTrainerForm");

    @Test
    void shouldSupport() {
        var actualResult = testInstance.supports(updateTrainerForm.getClass());

        assertTrue(actualResult);
    }

    @Test
    void shouldNotSupport() {
        var actualResult = testInstance.supports(anyObject.getClass());

        assertFalse(actualResult);
    }

    @Test
    void shouldNotRejectEnyField_whenEverythingIsOk() {
        testInstance.validate(updateTrainerForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_INVALID);
    }

    @Test
    void shouldNotRejectEnyField_whenOptionalFieldsAreEmpty() {
        when(updateTrainerForm.getSpecialization()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(updateTrainerForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_EMPTY);
    }

    @Test
    void shouldRejectFirstname_whenEmpty() {
        when(updateTrainerForm.getFirstName()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(updateTrainerForm, errors);

        verify(errors).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_INVALID);
    }

    @Test
    void shouldRejectLastname_whenEmpty() {
        when(updateTrainerForm.getLastName()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(updateTrainerForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_INVALID);
    }

    @Test
    void shouldRejectSpecialization_whenDoesNotExist() {
        when(updateTrainerForm.getSpecialization()).thenReturn(INVALID_SPECIALIZATION);

        testInstance.validate(updateTrainerForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_WHEN_SPECIALIZATION_INVALID);
    }
}