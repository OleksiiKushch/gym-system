package org.example.validator.user.trainer;

import org.example.dto.form.RegistrationTrainerForm;
import org.example.validator.user.OptionalPasswordsMatching;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class RegistrationTrainerFormValidator extends AbstractTrainerFieldsValidator implements Validator, OptionalPasswordsMatching {

    @Override
    public boolean supports(@NonNull Class<?> clazz) {
        return RegistrationTrainerForm.class.equals(clazz);
    }

    @Override
    public void validate(@NonNull Object target, @NonNull Errors errors) {
        RegistrationTrainerForm registrationTrainerForm = (RegistrationTrainerForm) target;

        validateTrainerFields(registrationTrainerForm.getFirstName(), registrationTrainerForm.getLastName(), registrationTrainerForm.getSpecialization(), errors);

        matchPasswords(registrationTrainerForm.getPassword(), registrationTrainerForm.getConfirmPassword(), errors);
    }
}
