package org.example.validator.user.trainer;

import org.example.dto.form.UpdateTrainerForm;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class UpdateTrainerFormValidator extends AbstractTrainerFieldsValidator implements Validator {
    @Override
    public boolean supports(@NonNull Class<?> clazz) {
        return UpdateTrainerForm.class.equals(clazz);
    }

    @Override
    public void validate(@NonNull Object target, @NonNull Errors errors) {
        UpdateTrainerForm updateTrainerForm = (UpdateTrainerForm) target;

        validateTrainerFields(updateTrainerForm.getFirstName(), updateTrainerForm.getLastName(), updateTrainerForm.getSpecialization(), errors);
    }
}
