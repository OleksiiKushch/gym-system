package org.example.validator.user.trainer;

import org.apache.commons.lang3.StringUtils;
import org.example.dto.form.RegistrationTrainerForm;
import org.example.entity.TrainingTypeEnum;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_FIELD;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.FIRST_NAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.FIRST_NAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.FIRST_NAME_FIELD;
import static org.example.constants.ValidationConstants.LAST_NAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.LAST_NAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.LAST_NAME_FIELD;
import static org.example.constants.ValidationConstants.SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.SPECIALIZATION_FIELD;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RegistrationTrainerFormValidatorUnitTest {

    private static final String FIRST_NAME = "John";
    private static final String LAST_NAME = "Doe";
    private static final String PASSWORD = "123456";
    private static final String CONFIRM_PASSWORD = "123456";
    private static final String SPECIALIZATION = TrainingTypeEnum.YOGA.name();
    private static final String INVALID_SPECIALIZATION = "TROLLING";

    private static final String EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_INVALID = "Specialization with name: YOGA does not exist";
    private static final String EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_EMPTY = "Specialization with name: does not exist";
    private static final String EXPECTED_MESSAGE_WHEN_SPECIALIZATION_INVALID = "Specialization with name: TROLLING does not exist";

    @Spy
    RegistrationTrainerFormValidator testInstance;

    @Mock
    Object anyObject;
    @Spy
    RegistrationTrainerForm registrationTrainerForm = new RegistrationTrainerForm(
            FIRST_NAME, LAST_NAME, PASSWORD, CONFIRM_PASSWORD, SPECIALIZATION);
    @Spy
    Errors errors  = new BeanPropertyBindingResult(registrationTrainerForm, "registrationTrainerForm");

    @Test
    void shouldSupport() {
        var actualResult = testInstance.supports(registrationTrainerForm.getClass());

        assertTrue(actualResult);
    }

    @Test
    void shouldNotSupport() {
        var actualResult = testInstance.supports(anyObject.getClass());

        assertFalse(actualResult);
    }

    @Test
    void shouldNotRejectEnyField_whenEverythingIsOk() {
        testInstance.validate(registrationTrainerForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_INVALID);
    }

    @Test
    void shouldNotRejectEnyField_whenOptionalFieldsAreEmpty() {
        when(registrationTrainerForm.getPassword()).thenReturn(StringUtils.EMPTY);
        when(registrationTrainerForm.getConfirmPassword()).thenReturn(StringUtils.EMPTY);
        when(registrationTrainerForm.getSpecialization()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(registrationTrainerForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_EMPTY);
    }

    @Test
    void shouldRejectFirstname_whenEmpty() {
        when(registrationTrainerForm.getFirstName()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(registrationTrainerForm, errors);

        verify(errors).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_INVALID);
    }

    @Test
    void shouldRejectLastname_whenEmpty() {
        when(registrationTrainerForm.getLastName()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(registrationTrainerForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_INVALID);
    }

    @Test
    void shouldNotRejectEnyField_whenPasswordsAreEmpty() {
        when(registrationTrainerForm.getPassword()).thenReturn(StringUtils.EMPTY);
        when(registrationTrainerForm.getConfirmPassword()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(registrationTrainerForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_INVALID);
    }

    @Test
    void shouldRejectConfirmPassword_whenPasswordMismatch_andPasswordIsNull() {
        when(registrationTrainerForm.getPassword()).thenReturn(null);

        testInstance.validate(registrationTrainerForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_INVALID);
    }

    @Test
    void shouldRejectConfirmPassword_whenPasswordMismatch_andConfirmPasswordIsNull() {
        when(registrationTrainerForm.getConfirmPassword()).thenReturn(null);

        testInstance.validate(registrationTrainerForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_IF_SPECIALIZATION_WERE_INVALID);
    }

    @Test
    void shouldRejectSpecialization_whenDoesNotExist() {
        when(registrationTrainerForm.getSpecialization()).thenReturn(INVALID_SPECIALIZATION);

        testInstance.validate(registrationTrainerForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors).rejectValue(SPECIALIZATION_FIELD, SPECIALIZATION_DOES_NOT_EXIST_MESSAGE_CODE, EXPECTED_MESSAGE_WHEN_SPECIALIZATION_INVALID);
    }
}