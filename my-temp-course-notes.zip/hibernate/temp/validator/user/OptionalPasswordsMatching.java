package org.example.validator.user;

import io.micrometer.common.util.StringUtils;
import org.springframework.validation.Errors;

import java.util.Objects;

import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_FIELD;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE;

public interface OptionalPasswordsMatching {

    default void matchPasswords(String password, String confirmPassword, Errors errors) {
        if (!(StringUtils.isEmpty(password) && StringUtils.isEmpty(confirmPassword))) {
            if (!Objects.equals(password, confirmPassword)) {
                errors.rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
            }
        }
    }
}
