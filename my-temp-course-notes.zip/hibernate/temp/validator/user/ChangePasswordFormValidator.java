package org.example.validator.user;

import org.apache.commons.lang3.StringUtils;
import org.example.dto.form.ChangePasswordForm;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import static org.example.constants.ValidationConstants.CURRENT_PASSWORD_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.CURRENT_PASSWORD_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.CURRENT_PASSWORD_FIELD;

@Component
public class ChangePasswordFormValidator implements Validator, NotOptionalPasswordsMatching {

    @Override
    public boolean supports(@NonNull Class<?> clazz) {
        return ChangePasswordForm.class.equals(clazz);
    }

    @Override
    public void validate(@NonNull Object target, @NonNull Errors errors) {
        ChangePasswordForm form = (ChangePasswordForm) target;

        if (StringUtils.isEmpty(form.getCurrentPassword())) {
            errors.rejectValue(CURRENT_PASSWORD_FIELD, CURRENT_PASSWORD_EMPTY_MESSAGE_CODE, CURRENT_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        }
        matchPasswords(form.getNewPassword(), form.getConfirmPassword(), errors);
    }
}
