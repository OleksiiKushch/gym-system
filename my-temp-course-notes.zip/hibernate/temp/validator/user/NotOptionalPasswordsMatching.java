package org.example.validator.user;

import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.Errors;

import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_FIELD;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.NEW_PASSWORD_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.NEW_PASSWORD_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.NEW_PASSWORD_FIELD;

public interface NotOptionalPasswordsMatching {

    default void matchPasswords(String newPassword, String confirmPassword, Errors errors) {
        if (StringUtils.isEmpty(newPassword)) {
            errors.rejectValue(NEW_PASSWORD_FIELD, NEW_PASSWORD_EMPTY_MESSAGE_CODE, NEW_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        }
        if (StringUtils.isEmpty(confirmPassword)) {
            errors.rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_EMPTY_MESSAGE_CODE, CONFIRM_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        }
        if (!errors.hasErrors() && !newPassword.equals(confirmPassword)) {
            errors.rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        }
    }
}
