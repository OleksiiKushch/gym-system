package org.example.validator.user.trainee;

import lombok.Getter;
import org.example.dto.form.UpdateTraineeForm;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.time.format.DateTimeFormatter;

@Getter
@Component
public class UpdateTraineeFormValidator extends AbstractTraineeFieldsValidator implements Validator {

    private final DateTimeFormatter dateTimeFormatter;

    public UpdateTraineeFormValidator(DateTimeFormatter dateTimeFormatter) {
        this.dateTimeFormatter = dateTimeFormatter;
    }

    @Override
    public boolean supports(@NonNull Class<?> clazz) {
        return UpdateTraineeForm.class.equals(clazz);
    }

    @Override
    public void validate(@NonNull Object target, @NonNull Errors errors) {
        UpdateTraineeForm updateTraineeForm = (UpdateTraineeForm) target;

        validateTraineeFields(updateTraineeForm.getFirstName(), updateTraineeForm.getLastName(), updateTraineeForm.getDateOfBirthday(), errors);
    }
}
