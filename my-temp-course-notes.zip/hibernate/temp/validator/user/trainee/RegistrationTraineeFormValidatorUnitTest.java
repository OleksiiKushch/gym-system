package org.example.validator.user.trainee;

import org.apache.commons.lang3.StringUtils;
import org.example.dto.form.RegistrationTraineeForm;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import java.time.format.DateTimeFormatter;

import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_FIELD;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.DATE_OF_BIRTHDAY_FIELD;
import static org.example.constants.ValidationConstants.FIRST_NAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.FIRST_NAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.FIRST_NAME_FIELD;
import static org.example.constants.ValidationConstants.INVALIDE_DATE_FORMAT_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.LAST_NAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.LAST_NAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.LAST_NAME_FIELD;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RegistrationTraineeFormValidatorUnitTest {

    private static final String FIRST_NAME = "John";
    private static final String LAST_NAME = "Doe";
    private static final String PASSWORD = "123456";
    private static final String CONFIRM_PASSWORD = "123456";
    private static final String DATE_OF_BIRTHDAY = "1990-01-01";
    private static final String ADDRESS = "123 Main St";
    private static final String DATE_IN_INCORRECT_FORMAT = "2/23/2021";
    private static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
    private static final String EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_IN_INCORRECT_FORMAT = "This is invalid date format: 1990-01-01";
    private static final String EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_EMPTY = "This is invalid date format: ";
    private static final String EXPECTEDD_MESSAGE_IF_DATE_OF_BIRTH_IN_INCORRECT_FORMAT = "This is invalid date format: 2/23/2021";

    @InjectMocks
    RegistrationTraineeFormValidator testInstance;

    @Spy
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DEFAULT_DATE_FORMAT);

    @Mock
    Object anyObject;
    @Spy
    RegistrationTraineeForm registrationTraineeForm = new RegistrationTraineeForm(
            FIRST_NAME, LAST_NAME, PASSWORD, CONFIRM_PASSWORD, DATE_OF_BIRTHDAY, ADDRESS);
    @Spy
    Errors errors  = new BeanPropertyBindingResult(registrationTraineeForm, "registrationTraineeForm");

    @Test
    void shouldSupport() {
        var actualResult = testInstance.supports(registrationTraineeForm.getClass());

        assertTrue(actualResult);
    }

    @Test
    void shouldNotSupport() {
        var actualResult = testInstance.supports(anyObject.getClass());

        assertFalse(actualResult);
    }

    @Test
    void shouldNotRejectEnyField_whenEverythingIsOk() {
        testInstance.validate(registrationTraineeForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldNotRejectEnyField_whenOptionalFieldsAreEmpty() {
        when(registrationTraineeForm.getPassword()).thenReturn(StringUtils.EMPTY);
        when(registrationTraineeForm.getConfirmPassword()).thenReturn(StringUtils.EMPTY);
        when(registrationTraineeForm.getDateOfBirthday()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(registrationTraineeForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_EMPTY);
    }

    @Test
    void shouldRejectFirstname_whenEmpty() {
        when(registrationTraineeForm.getFirstName()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(registrationTraineeForm, errors);

        verify(errors).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldRejectLastname_whenEmpty() {
        when(registrationTraineeForm.getLastName()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(registrationTraineeForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldNotRejectEnyField_whenPasswordsAreEmpty() {
        when(registrationTraineeForm.getPassword()).thenReturn(StringUtils.EMPTY);
        when(registrationTraineeForm.getConfirmPassword()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(registrationTraineeForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldRejectConfirmPassword_whenPasswordMismatch_andPasswordIsNull() {
        when(registrationTraineeForm.getPassword()).thenReturn(null);

        testInstance.validate(registrationTraineeForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldRejectConfirmPassword_whenPasswordMismatch_andConfirmPasswordIsNull() {
        when(registrationTraineeForm.getConfirmPassword()).thenReturn(null);

        testInstance.validate(registrationTraineeForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldRejectDateOfBirthday_whenIncorrectFormat() {
        when(registrationTraineeForm.getDateOfBirthday()).thenReturn(DATE_IN_INCORRECT_FORMAT);

        testInstance.validate(registrationTraineeForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
        verify(errors).rejectValue(DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTEDD_MESSAGE_IF_DATE_OF_BIRTH_IN_INCORRECT_FORMAT);
    }
}