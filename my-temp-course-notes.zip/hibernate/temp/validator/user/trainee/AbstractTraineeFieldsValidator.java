package org.example.validator.user.trainee;

import org.apache.commons.lang3.StringUtils;
import org.example.validator.DateValidation;
import org.example.validator.user.AbstractUserFieldsValidator;
import org.springframework.validation.Errors;

import static org.example.constants.ValidationConstants.DATE_OF_BIRTHDAY_FIELD;
import static org.example.constants.ValidationConstants.INVALIDE_DATE_FORMAT_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.INVALIDE_DATE_FORMAT_MESSAGE_CODE;

public abstract class AbstractTraineeFieldsValidator extends AbstractUserFieldsValidator implements DateValidation {

    protected void validateTraineeFields(String firstName, String lastName, String dateOfBirthday, Errors errors) {

        validateUserFields(firstName, lastName, errors);

        if (StringUtils.isNotEmpty(dateOfBirthday)) {
            validateDate(dateOfBirthday, DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, INVALIDE_DATE_FORMAT_DEFAULT_MESSAGE, errors);
        }
    }
}
