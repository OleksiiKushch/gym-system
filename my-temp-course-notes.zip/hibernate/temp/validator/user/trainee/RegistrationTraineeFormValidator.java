package org.example.validator.user.trainee;

import lombok.Getter;
import org.example.dto.form.RegistrationTraineeForm;
import org.example.validator.user.OptionalPasswordsMatching;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.time.format.DateTimeFormatter;

@Getter
@Component
public class RegistrationTraineeFormValidator extends AbstractTraineeFieldsValidator implements Validator, OptionalPasswordsMatching {

    private final DateTimeFormatter dateTimeFormatter;

    public RegistrationTraineeFormValidator(DateTimeFormatter dateTimeFormatter) {
        this.dateTimeFormatter = dateTimeFormatter;
    }

    @Override
    public boolean supports(@NonNull Class<?> clazz) {
        return RegistrationTraineeForm.class.equals(clazz);
    }

    @Override
    public void validate(@NonNull Object target, @NonNull Errors errors) {
        RegistrationTraineeForm registrationTraineeForm = (RegistrationTraineeForm) target;

        validateTraineeFields(registrationTraineeForm.getFirstName(), registrationTraineeForm.getLastName(), registrationTraineeForm.getDateOfBirthday(), errors);

        matchPasswords(registrationTraineeForm.getPassword(), registrationTraineeForm.getConfirmPassword(), errors);
    }
}
