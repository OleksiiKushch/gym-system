package org.example.validator.user.trainee;

import org.apache.commons.lang3.StringUtils;
import org.example.dto.form.UpdateTraineeForm;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import java.time.format.DateTimeFormatter;

import static org.example.constants.ValidationConstants.DATE_OF_BIRTHDAY_FIELD;
import static org.example.constants.ValidationConstants.FIRST_NAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.FIRST_NAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.FIRST_NAME_FIELD;
import static org.example.constants.ValidationConstants.INVALIDE_DATE_FORMAT_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.LAST_NAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.LAST_NAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.LAST_NAME_FIELD;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UpdateTraineeFormValidatorUnitTest {

    private static final String FIRST_NAME = "John";
    private static final String LAST_NAME = "Doe";
    private static final String DATE_OF_BIRTHDAY = "1990-01-01";
    private static final String ADDRESS = "Some address";
    private static final String DATE_IN_INCORRECT_FORMAT = "2/23/2021";
    private static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
    private static final String EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_IN_INCORRECT_FORMAT = "This is invalid date format: 1990-01-01";
    private static final String EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_EMPTY = "This is invalid date format: ";
    private static final String EXPECTEDD_MESSAGE_IF_DATE_OF_BIRTH_IN_INCORRECT_FORMAT = "This is invalid date format: 2/23/2021";

    @InjectMocks
    UpdateTraineeFormValidator testInstance;

    @Spy
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DEFAULT_DATE_FORMAT);

    @Mock
    Object anyObject;
    @Spy
    UpdateTraineeForm updateTraineeForm = new UpdateTraineeForm(
            FIRST_NAME, LAST_NAME, DATE_OF_BIRTHDAY, ADDRESS);
    @Spy
    Errors errors  = new BeanPropertyBindingResult(updateTraineeForm, "updateTraineeForm");

    @Test
    void shouldSupport() {
        var actualResult = testInstance.supports(updateTraineeForm.getClass());

        assertTrue(actualResult);
    }

    @Test
    void shouldNotSupport() {
        var actualResult = testInstance.supports(anyObject.getClass());

        assertFalse(actualResult);
    }

    @Test
    void shouldNotRejectEnyField_whenEverythingIsOk() {
        testInstance.validate(updateTraineeForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldNotRejectEnyField_whenOptionalFieldsAreEmpty() {
        when(updateTraineeForm.getDateOfBirthday()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(updateTraineeForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_EMPTY);
    }

    @Test
    void shouldRejectFirstname_whenEmpty() {
        when(updateTraineeForm.getFirstName()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(updateTraineeForm, errors);

        verify(errors).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldRejectLastname_whenEmpty() {
        when(updateTraineeForm.getLastName()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(updateTraineeForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTED_MESSAGE_IF_DATE_OF_BIRTH_WERE_IN_INCORRECT_FORMAT);
    }

    @Test
    void shouldRejectDateOfBirthday_whenIncorrectFormat() {
        when(updateTraineeForm.getDateOfBirthday()).thenReturn(DATE_IN_INCORRECT_FORMAT);

        testInstance.validate(updateTraineeForm, errors);

        verify(errors, never()).rejectValue(FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(DATE_OF_BIRTHDAY_FIELD, INVALIDE_DATE_FORMAT_MESSAGE_CODE, EXPECTEDD_MESSAGE_IF_DATE_OF_BIRTH_IN_INCORRECT_FORMAT);
    }
}