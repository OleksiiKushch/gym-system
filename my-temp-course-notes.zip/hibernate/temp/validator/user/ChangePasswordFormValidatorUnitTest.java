package org.example.validator.user;

import org.apache.commons.lang3.StringUtils;
import org.example.dto.form.ChangePasswordForm;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_FIELD;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.CURRENT_PASSWORD_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.CURRENT_PASSWORD_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.CURRENT_PASSWORD_FIELD;
import static org.example.constants.ValidationConstants.NEW_PASSWORD_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.NEW_PASSWORD_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.NEW_PASSWORD_FIELD;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ChangePasswordFormValidatorUnitTest {

    private static final String CURRENT_PASSWORD = "123456";
    private static final String NEW_PASSWORD = "654321";
    private static final String CONFIRM_PASSWORD = "654321";
    private static final String SOME_NON_MUTCHING_PASSWORD = "654322";

    @Spy
    ChangePasswordFormValidator testInstance;

    @Mock
    Object anyObject;
    @Spy
    ChangePasswordForm changePasswordForm = new ChangePasswordForm(CURRENT_PASSWORD, NEW_PASSWORD, CONFIRM_PASSWORD);
    @Spy
    Errors errors  = new BeanPropertyBindingResult(changePasswordForm, "changePasswordForm");

    @Test
    void shouldSupport() {
        var actualResult = testInstance.supports(changePasswordForm.getClass());

        assertTrue(actualResult);
    }

    @Test
    void shouldNotSupport() {
        var actualResult = testInstance.supports(anyObject.getClass());

        assertFalse(actualResult);
    }

    @Test
    void shouldNotRejectEnyField_whenEverythingIsOk() {
        testInstance.validate(changePasswordForm, errors);

        verify(errors, never()).rejectValue(CURRENT_PASSWORD_FIELD, CURRENT_PASSWORD_EMPTY_MESSAGE_CODE, CURRENT_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(NEW_PASSWORD_FIELD, NEW_PASSWORD_EMPTY_MESSAGE_CODE, NEW_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_EMPTY_MESSAGE_CODE, CONFIRM_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
    }

    @Test
    void shouldRejectCurrentPassword_whenEmpty() {
        when(changePasswordForm.getCurrentPassword()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(changePasswordForm, errors);

        verify(errors).rejectValue(CURRENT_PASSWORD_FIELD, CURRENT_PASSWORD_EMPTY_MESSAGE_CODE, CURRENT_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(NEW_PASSWORD_FIELD, NEW_PASSWORD_EMPTY_MESSAGE_CODE, NEW_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_EMPTY_MESSAGE_CODE, CONFIRM_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
    }

    @Test
    void shouldRejectNewPassword_whenEmpty() {
        when(changePasswordForm.getNewPassword()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(changePasswordForm, errors);

        verify(errors, never()).rejectValue(CURRENT_PASSWORD_FIELD, CURRENT_PASSWORD_EMPTY_MESSAGE_CODE, CURRENT_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(NEW_PASSWORD_FIELD, NEW_PASSWORD_EMPTY_MESSAGE_CODE, NEW_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_EMPTY_MESSAGE_CODE, CONFIRM_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
    }

    @Test
    void shouldRejectConfirmPassword_whenEmpty() {
        when(changePasswordForm.getConfirmPassword()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(changePasswordForm, errors);

        verify(errors, never()).rejectValue(CURRENT_PASSWORD_FIELD, CURRENT_PASSWORD_EMPTY_MESSAGE_CODE, CURRENT_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(NEW_PASSWORD_FIELD, NEW_PASSWORD_EMPTY_MESSAGE_CODE, NEW_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_EMPTY_MESSAGE_CODE, CONFIRM_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
    }

    @Test
    void shouldRejectConfirmPassword_whenNewAndConfirmPasswordsNotMatch() {
        when(changePasswordForm.getConfirmPassword()).thenReturn(SOME_NON_MUTCHING_PASSWORD);

        testInstance.validate(changePasswordForm, errors);

        verify(errors, never()).rejectValue(CURRENT_PASSWORD_FIELD, CURRENT_PASSWORD_EMPTY_MESSAGE_CODE, CURRENT_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(NEW_PASSWORD_FIELD, NEW_PASSWORD_EMPTY_MESSAGE_CODE, NEW_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_EMPTY_MESSAGE_CODE, CONFIRM_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
    }

    @Test
    void shouldRejectSomeFields_whenTheyAreEmpty() {
        when(changePasswordForm.getCurrentPassword()).thenReturn(StringUtils.EMPTY);
        when(changePasswordForm.getConfirmPassword()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(changePasswordForm, errors);

        verify(errors).rejectValue(CURRENT_PASSWORD_FIELD, CURRENT_PASSWORD_EMPTY_MESSAGE_CODE, CURRENT_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(NEW_PASSWORD_FIELD, NEW_PASSWORD_EMPTY_MESSAGE_CODE, NEW_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_EMPTY_MESSAGE_CODE, CONFIRM_PASSWORD_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(CONFIRM_PASSWORD_FIELD, CONFIRM_PASSWORD_NOT_MATCH_MESSAGE_CODE, CONFIRM_PASSWORD_NOT_MATCH_DEFAULT_MESSAGE);
    }
}