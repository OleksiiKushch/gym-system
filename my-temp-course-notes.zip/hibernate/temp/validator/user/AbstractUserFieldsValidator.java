package org.example.validator.user;

import org.example.validator.EmptyFieldValidation;
import org.springframework.validation.Errors;

import static org.example.constants.ValidationConstants.FIRST_NAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.FIRST_NAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.FIRST_NAME_FIELD;
import static org.example.constants.ValidationConstants.LAST_NAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.LAST_NAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.LAST_NAME_FIELD;

public abstract class AbstractUserFieldsValidator implements EmptyFieldValidation {

    protected void validateUserFields(String firstName, String lastName, Errors errors) {
        checkEmptyField(firstName, FIRST_NAME_FIELD, FIRST_NAME_EMPTY_MESSAGE_CODE, FIRST_NAME_EMPTY_DEFAULT_MESSAGE, errors);
        checkEmptyField(lastName, LAST_NAME_FIELD, LAST_NAME_EMPTY_MESSAGE_CODE, LAST_NAME_EMPTY_DEFAULT_MESSAGE, errors);
    }
}
