package org.example.validator.user;

import org.apache.commons.lang3.StringUtils;
import org.example.dto.form.LoginForm;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.validation.Errors;

import static org.example.constants.ValidationConstants.PASSWORD_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.PASSWORD_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.PASSWORD_FIELD;
import static org.example.constants.ValidationConstants.USERNAME_EMPTY_DEFAULT_MESSAGE;
import static org.example.constants.ValidationConstants.USERNAME_EMPTY_MESSAGE_CODE;
import static org.example.constants.ValidationConstants.USERNAME_FIELD;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LoginFormValidatorUnitTest {

    private static final String TEST_USERNAME = "John.Doe";
    private static final String TEST_PASSWORD = "123456";

    @Spy
    LoginFormValidator testInstance;

    @Spy
    LoginForm loginForm = new LoginForm(TEST_USERNAME, TEST_PASSWORD);
    @Mock
    Object anyObject;
    @Mock
    Errors errors;

    @Test
    void shouldSupport() {
        var actualResult = testInstance.supports(loginForm.getClass());

        assertTrue(actualResult);
    }

    @Test
    void shouldNotSupport() {
        var actualResult = testInstance.supports(anyObject.getClass());

        assertFalse(actualResult);
    }

    @Test
    void shouldNotRejectAnyField_whenEverythingIsOk() {
        testInstance.validate(loginForm, errors);

        verify(errors, never()).rejectValue(USERNAME_FIELD, USERNAME_EMPTY_MESSAGE_CODE, USERNAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(PASSWORD_FIELD, PASSWORD_EMPTY_MESSAGE_CODE, PASSWORD_EMPTY_DEFAULT_MESSAGE);
    }

    @Test
    void shouldRejectUsername_whenEmpty() {
        when(loginForm.getUsername()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(loginForm, errors);

        verify(errors).rejectValue(USERNAME_FIELD, USERNAME_EMPTY_MESSAGE_CODE, USERNAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors, never()).rejectValue(PASSWORD_FIELD, PASSWORD_EMPTY_MESSAGE_CODE, PASSWORD_EMPTY_DEFAULT_MESSAGE);
    }

    @Test
    void shouldRejectPassword_whenEmpty() {
        when(loginForm.getPassword()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(loginForm, errors);

        verify(errors, never()).rejectValue(USERNAME_FIELD, USERNAME_EMPTY_MESSAGE_CODE, USERNAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(PASSWORD_FIELD, PASSWORD_EMPTY_MESSAGE_CODE, PASSWORD_EMPTY_DEFAULT_MESSAGE);
    }

    @Test
    void shouldRejectAllFields_whenEverythingIsEmpty() {
        when(loginForm.getUsername()).thenReturn(StringUtils.EMPTY);
        when(loginForm.getPassword()).thenReturn(StringUtils.EMPTY);

        testInstance.validate(loginForm, errors);

        verify(errors).rejectValue(USERNAME_FIELD, USERNAME_EMPTY_MESSAGE_CODE, USERNAME_EMPTY_DEFAULT_MESSAGE);
        verify(errors).rejectValue(PASSWORD_FIELD, PASSWORD_EMPTY_MESSAGE_CODE, PASSWORD_EMPTY_DEFAULT_MESSAGE);
    }
}